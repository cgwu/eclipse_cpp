﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Diagnostics;

namespace MSMQNoSecurityService
{
    public class MSMQService : IMSMQService
    {
        public void ShowMessage(string msg)
        {
            Debug.WriteLine(msg + " Received at: " + System.DateTime.Now.ToString());
        }
    }
}
