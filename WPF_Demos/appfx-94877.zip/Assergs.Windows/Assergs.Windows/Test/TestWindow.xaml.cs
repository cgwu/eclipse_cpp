﻿# region MyRegion

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media; 

# endregion

namespace Assergs.Windows.Tests
{
	public partial class TestWindow : ToolWindow
	{
		public TestWindow()
		{
			this.InitializeComponent();
		}
	}
}