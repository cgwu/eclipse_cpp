﻿using System;

namespace Assergs.Windows.Media
{
	public enum ColorType
	{		
		HSL,
		HSV
	}
}
