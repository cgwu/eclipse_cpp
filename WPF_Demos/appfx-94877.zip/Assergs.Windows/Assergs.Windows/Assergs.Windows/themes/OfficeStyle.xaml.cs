﻿using System;
using System.Windows;

namespace Assergs.Windows
{
	public partial class OfficeStyle : ResourceDictionary
	{
		public OfficeStyle()
		{
			this.InitializeComponent(); 
		}
	}
}
