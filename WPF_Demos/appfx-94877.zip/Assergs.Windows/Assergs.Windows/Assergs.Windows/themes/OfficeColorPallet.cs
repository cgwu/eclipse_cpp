﻿using System;

namespace Assergs.Windows
{
	public enum OfficeColorPallet
	{
		Background,
		Foreground,
		HighLight,
		Disabled,
        EditableControlsBackground,
        None
	}
}
