﻿using System;

namespace Assergs.Windows
{
    public enum ToolWindowModal
	{
		Application,
		AncestralOwners,
		Owner
	}
}
