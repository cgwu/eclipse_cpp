﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assergs.Windows.Controls
{
    public delegate void NoArgsEventHandler();
}
